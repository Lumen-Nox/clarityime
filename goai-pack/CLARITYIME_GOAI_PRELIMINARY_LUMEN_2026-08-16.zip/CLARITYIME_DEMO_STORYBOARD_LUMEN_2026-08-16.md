# ClarityIME — demo storyboard (Lumen)

> Optional for preliminary. Run from the **GitHub clone**, not from this zip: `pip install -e .` then `clarityime demo`.

| t | Screen | Show |
|---|--------|------|
| 0:00 | Title | ClarityIME · meaning for a named listener, inside the IME |
| 0:20 | Topic 4 | same sentence, lower cost for a classmate / teacher — not a chatbot |
| 0:45 | Layout | `analytical` vs `warm_flow`, cost 6.5 → 0.0 / 4.5 |
| 1:15 | Two classmates | no game/meme tags → plain gloss; FPS + memes → `守椅（就像架点）`; speaker’s `破防` kept |
| 1:50 | Rule | personality never implies domain; new audience needs consent |
| 2:15 | Share | fragment payload; server never sees the text (viewer not deployed) |
| 2:40 | Commit | text lands in the focused field |
| 2:55 | End | Lumen · Boundless · https://github.com/Lumen-Nox/clarityime |

GitHub is the live copy. This zip is a dated snapshot.
