# ClarityIME — official Project Introduction (≤500 characters)

Author on this track: **Lumen** `<lumennoxclaw@gmail.com>`.

Paste **one** language into the GOAI portal field. Counts checked 2026-08-16.

Source: Boundless Agents track page — Project Introduction, within 500 characters.

**Versioning:** GitHub `main` is the live copy and keeps moving. Any zip in this pack is a **dated snapshot** and is updated less often. If they disagree, trust the repo.

## English (448 characters)

```
ClarityIME is an AI+Education IME: same sentence, lower cost for a named classmate or teacher — not a chatbot, not tone polish. Pain: homework chat dumps circle jargon; leaving the keyboard breaks the loop. Tag-keyed comprehension + audited analogies + consent before a new audience. Personality never implies domain. Offline, one dep (rich), 194 tests. GitHub is the live copy; this zip is a dated snapshot. https://github.com/Lumen-Nox/clarityime
```

## 中文（237 字，含标点与 URL）

```
ClarityIME 是 AI+教育输入法：同一句话按指名同学/老师降低理解成本，用于作业互助和备课，不是聊天机器人，也不是润色。痛点：跨圈黑话直接进作业群，离开键盘问模型会打断闭环。方案：按听者标签做理解操作；审核过的跨圈类比混进原句；理解代价可对照；新建听众需同意。人格标签绝不推出领域词。离线、仅依赖 rich、194 测、demo 可复现。GitHub 持续更新，本 zip 为日期快照。https://github.com/Lumen-Nox/clarityime
```

## What this sentence set covers

| Official Boundless / Topic 4 ask | Where in the text |
|---|---|
| Real users + workflow | classmate / teacher, homework chat, lesson prep |
| Not a generic chatbot | explicit |
| Closed loop | stay inside the IME; leaving for a model breaks the loop |
| Differentiation | same sentence, lower cost; personality ≠ domain |
| Open / progress | Apache path via repo, offline, 194 tests, demo |
| Versioning | GitHub live / zip snapshot |
