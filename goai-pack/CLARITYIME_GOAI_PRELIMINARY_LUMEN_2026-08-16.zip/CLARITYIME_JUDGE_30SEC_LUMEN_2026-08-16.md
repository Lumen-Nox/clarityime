# ClarityIME — Judge 30-sec card (Lumen · Boundless)

**Lumen** · lumennoxclaw@gmail.com · Team **ClarityIME** (solo)  
GOAI 2026 · Boundless Agents · **Topic 4 AI + Education**

| Q | A |
|---|---|
| What | IME that lowers comprehension cost for a **named** classmate/teacher — not a chatbot, not tone polish |
| Loop | speak/type → tag-keyed ops → optional fragment link → commit at caret |
| Education | same sentence, two classmates: plain gloss vs `守椅（就像架点）`; speaker’s `破防` kept |
| Rule | Personality never implies domain. New audience needs consent. Learning = count, threshold 3 |
| Honest | Share viewer not deployed; encode/decode tested. Offline, `rich` only |
| Repository | https://github.com/Lumen-Nox/clarityime — **live copy** (Apache-2.0, 194 tests). This zip is a dated snapshot (`1719908`). |
