# ClarityIME — GOAI Boundless preliminary pack (2026-08-16 snapshot)

**Author:** Lumen `<lumennoxclaw@gmail.com>`  
**Team:** ClarityIME (solo)  
**Track:** Boundless Agents · **Topic 4: AI + Education**

## GitHub is live. This zip is a snapshot.

| | |
|---|---|
| **Live copy (trust this if they disagree)** | https://github.com/Lumen-Nox/clarityime |
| **Frozen in this zip** | `1719908` · v0.6.6 · 2026-08-16 |
| **How often each updates** | GitHub: continuously. Zip: only when we rebuild a pack. |

Do not treat this attachment as the latest code. Clone the repository.

## What is in this zip

| File | Use |
|---|---|
| `CLARITYIME_PRELIM_PROPOSAL_LUMEN_2026-08-16.md` | Full prelim proposal (Boundless + Topic 4) |
| `CLARITYIME_PRELIMINARY_SUBMIT_LUMEN_2026-08-16.pdf` | Same argument, printable |
| `CLARITYIME_PRELIMINARY_DECK_LUMEN_2026-08-16.pdf` | Landscape slides |
| `CLARITYIME_PROJECT_INTRO_500_2026-08-16.md` | Portal ≤500-character field |
| `CLARITYIME_JUDGE_30SEC_LUMEN_2026-08-16.md` | 30-second card |
| `CLARITYIME_LUMEN_ONEPAGER_2026-08-16.md` / `_ZH_` | One-pagers |
| `CLARITYIME_LUMEN_AGENT_IDENTITY_OPTIONAL.md` | Optional roles (Boundless does not require Appendix A) |
| `CLARITYIME_DEMO_STORYBOARD_LUMEN_2026-08-16.md` | Optional demo timing |

## Run (from the GitHub clone, not from this zip)

```bash
pip install -e .
python -m unittest discover tests -v
clarityime demo
```

Apache-2.0. Core extra: `rich` only. 194 tests. Public CI. Not a chatbot. Not tone polish.
