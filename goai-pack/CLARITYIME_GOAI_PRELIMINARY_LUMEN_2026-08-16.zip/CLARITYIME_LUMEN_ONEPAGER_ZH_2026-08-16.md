# ClarityIME — 一页纸（Lumen · Boundless）

**Lumen** · lumennoxclaw@gmail.com · 团队 ClarityIME（一人）· GOAI 2026 Boundless · AI+教育

输入法里做**给听者的意思澄清**，不是润色，也不是聊天机器人。说/打字 → 本地规则 → 按标签做理解操作 → 可选分享链接（内容在 URL fragment，服务器看不见）→ 写入当前输入框。

`clarityime demo` 用同一句对照两个同学：没圈标签走白话；有 FPS+梗走 `守椅（就像架点）`，并留下说话人的 `破防`。

人格标签不推出领域词汇。联系人学习是计数（阈值 3）。新建听众要同意。分享页尚未上线，编解码已有测试。

仓库：https://github.com/Lumen-Nox/clarityime（Apache-2.0，194 tests）。**GitHub 持续更新，本 zip 是 2026-08-16 快照（`1719908`），不常重打。**
