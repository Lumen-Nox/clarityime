# ClarityIME — GOAI 2026 Boundless preliminary proposal

**Author:** Lumen · lumennoxclaw@gmail.com  
**Team:** ClarityIME (solo)  
**Track:** Boundless Agents · **Topic 4: AI + Education**  
**Date:** 2026-08-16  
**Repo (live):** https://github.com/Lumen-Nox/clarityime  
**Frozen in this zip:** `1719908` · v0.6.6 · 2026-08-16  
**License:** Apache-2.0 · **core extra:** `rich` only · **tests:** 194 · **CI:** Ubuntu/Windows × Python 3.9/3.12

> **GitHub vs zip.** The public repository on `main` is updated continuously. This zip is a dated snapshot and is rebuilt less often. If a number, command, or SHA here disagrees with GitHub, **trust GitHub**.

This is the public Boundless entry. It is not a generic chatbot and not a tone polisher.

Scoring source: [Boundless Agents track page](https://www.goaihz.com/en/tracks?track=apps) (Beijing Time). Topic 4 focus on the same page: personalized learning, homework support, learning diagnosis, teacher lesson preparation, learning companionship.

---

## 1. Industry scenario value

| Official Topic 4 focus | This entry |
|---|---|
| Personalized learning | A *named* listener (classmate, teacher, younger sibling) with declared tags |
| Homework support | Same homework sentence, cheaper to read, still the speaker’s hedges and questions |
| Learning diagnosis | Printed comprehension cost before → after (`clarityime demo`) |
| Teacher lesson prep | `analytical` vs `warm_flow` layouts of the same propositions |
| Learning companionship | Affect-first order for Fi/Fe listeners; feeling words stay as details |

**Users:** students explaining work to a classmate who does not share their game / meme / course circle; teachers reading student messages.

**Pain:** the IME dumps circle jargon into the homework chat. Leaving the keyboard for a chatbot breaks the closed loop the track asks for.

**Replicable:** any classroom where two people do not own the same vocabulary. The analogy table is audited 1:1, not generated.

---

## 2. Agent capabilities and closed-loop task

```
speak / type → local rules (still the speaker’s words)
             → comprehension ops keyed on listener tags
             → optional fragment share link
             → commit into the focused field
             → optional rating → contact learning (count, threshold 3)
```

This is one demonstrable closed-loop task: **make this sentence readable for that person, then put it where they were already typing.**

| Boundless “do not encourage” | How this entry refuses it |
|---|---|
| Generic chatbot | No LLM on the core path. Determinism test AST-scans `clarify/` for HTTP / LLM / `random` |
| Single-point Q&A | Output is the speaker’s propositions, re-laid, not an answer |
| Simple content generator | Invariants reject new content, lost content, dropped hedges, flipped questions |

Roles in the loop (not three cloud agents — Boundless scores a **task loop**, not Agent Infra’s 3-agent quota):

| Role | Job | Boundary |
|---|---|---|
| Speaker model | keep stance, hedges, questions | never rewrite opinion |
| Listener model | tags + Cerome numbers pick ops | personality **never** implies a domain |
| Comprehension engine | referents, claim-first, jargon, analogy | tabled substitutions only |
| Consent / learning | `auto_name_preview`; threshold 3 | DEFAULT ratings do not silently create a contact |

---

## 3. Product experience and demo completeness

A judge runs:

```bash
pip install -e .
clarityime demo
```

The demo shows:

1. One long spoken sentence → `analytical` vs `warm_flow` (cost 6.5 → 0.0 / 4.5).
2. **The same sentence, two classmates:** no game/meme tags → plain gloss; FPS + memes → `守椅（就像架点）` and the speaker’s `破防` kept.

That is the education claim in 30 seconds: cross-circle teaching without leaving the IME.

Honest limit: the share viewer at `clarityime.app` is **not deployed**. `encode` / `decode` of the fragment payload is tested. Linux/macOS/iOS trees are source, not the scored demo path.

---

## 4. Technical depth and reproducibility

| Claim | Check |
|---|---|
| Personality ≠ domain | `mbti_intj` does not grant tech/game words |
| Cross-circle analogy | `clarify/analogy.py` 1:1; no owned analog → plain T1 |
| Affect-first | `A8a` reorders, does not invent |
| Contact learning | counts only; threshold 3; same evidence → same outcome |
| Determinism | `tests/test_determinism.py` |
| Invariants | no new/lost content; hedges; polarity; speech-act |
| CI | 194 tests + `clarityime demo` with `PYTHONIOENCODING=utf-8` |

No model, no embedding, no cloud on the clarify path.

---

## 5. Safety, compliance, open reuse

| Boundary | Mechanism |
|---|---|
| Data stays local | loopback API (`127.0.0.1`); mutating calls need a local token |
| Share link | payload in the URL **fragment**; a server never sees the message |
| Consent | `cloud_sync` / research flags default off; new audience needs yes/no |
| Age / gender / place | never grant vocabulary or pick a language |
| License | Apache-2.0; core extra is `rich` |

---

## Feasibility / next step (semi-final 9/3 if advanced)

| Now | If advanced |
|---|---|
| Offline demo + HTTP clarify + 194 tests | One recorded demo of the two-classmate contrast; optional hosted fragment viewer (still no server-side message body) |

---

## Reproduce

```bash
pip install -e .
python -m unittest discover tests -v
clarityime demo
clarityime clarify "监管者一直守椅" --listener analytical
```
