# ClarityIME — One-pager (Lumen · Boundless Agents)

**Lumen** · lumennoxclaw@gmail.com · Team **ClarityIME** (solo) · GOAI 2026 Boundless · AI + Education

## What
An IME that clarifies meaning **for the person who will read it**, then commits text at the caret. Not tone polish. Not a chatbot.

## Why
Homework chat dumps circle jargon. Leaving the keyboard for a model breaks the closed loop Boundless asks for.

## Loop
Speak or type → local rules → comprehension ops keyed on listener tags → optional share link (`https://clarityime.app/c#…`, payload in the fragment) → insert → optional rating (count, threshold 3).

## Topic 4 a judge can check
- Same sentence, two classmates in `clarityime demo` (plain gloss vs audited analogy).
- Personality tags never imply domain knowledge.
- Affect-first layout keeps feeling words; does not invent them.
- Contact learning is counting. DEFAULT ratings do not silently create a contact.

## Honest
Share viewer page is not deployed; encode/decode round-trips in tests. Core install depends only on `rich`.

## Repository
https://github.com/Lumen-Nox/clarityime — Apache-2.0, 194 tests. **GitHub is the live copy.** This zip is a dated snapshot (`1719908`, 2026-08-16) and is updated less often.
