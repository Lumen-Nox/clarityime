# ClarityIME — Optional light Agent Identity (Boundless, stripped)

> Boundless does **not** require Appendix A. Include only if reviewers ask “is this multi-agent?”  
> Author: **Lumen** · lumennoxclaw@gmail.com · Team ClarityIME · 2026-08-16  
> Live repo: https://github.com/Lumen-Nox/clarityime — this file in a zip is a snapshot.

| Name | Role | Capabilities | Inputs | Outputs | Dependencies | Decision Boundary | Trace |
|------|------|--------------|--------|---------|--------------|-------------------|-------|
| listen-agent | Capture speech | ASR N-best (optional) | mic audio | candidate strings | local ASR | no cloud unless consent | log ASR latency |
| clarify-agent | Keep meaning | remove fillers, fix logic, punctuation | ASR text | clarified text | local rules | must preserve user intent | log before/after |
| audience-agent | Adapt register | default / contact / listener tags | clarified text + tags | tag-keyed candidates | local contact profile | personality never implies domain | log tags used |
| commit-agent | IME insert | commitText / TSF inject | chosen candidate | text in focused field | OS IME APIs | never send off-device by default | log commit success |

**Strip rule:** no private research notes, no cloud as a required path.
